#include "prefix_sum.h"
#include "helpers.h"

void* compute_prefix_sum(void *a)
{
    //prefix_sum_args_t *args = (prefix_sum_args_t *)a;

    /************************
     * Your code here...    *
     * or wherever you like *
     ************************/

    return 0;
}
